public class GorrillaTest{

    public static void main(String args[]) {

        Gorrilla DonkeyKong = new Gorrilla();

        DonkeyKong.throwSomething();
        DonkeyKong.throwSomething();
        DonkeyKong.throwSomething();
        

        DonkeyKong.eatBananas();
        DonkeyKong.eatBananas();

        DonkeyKong.climb();

        System.out.println("His power level is over:");
        DonkeyKong.displayEnergy();
        }
} //void main ends