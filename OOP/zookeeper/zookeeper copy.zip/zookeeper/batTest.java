

public class batTest {
    public static void main(String args[]) {

        bat MegaBat = new bat();

        MegaBat.attackTown();
        MegaBat.attackTown();
        MegaBat.attackTown();
        

        MegaBat.eatHumans();
        MegaBat.eatHumans();

        MegaBat.fly();
        MegaBat.fly();

        System.out.println("His power level is over:");
        MegaBat.displayEnergy();
        }
} //void main ends

