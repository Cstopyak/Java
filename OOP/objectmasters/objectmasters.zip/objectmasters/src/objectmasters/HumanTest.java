package objectmasters;

public class HumanTest {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human Human1 = new Human("Colby");

		Human1.getHealth();
		Human1.getIntelligence();
		Human1.getStealth();
		Human1.getStrength();
		Human1.attack(Human1);
		System.out.println(Human1.getHealth());
	}

}
